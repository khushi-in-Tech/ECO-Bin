// ==========================================
// ECOBIN - JavaScript Controller
// ==========================================

// State Management
let currentScreen = 'home-screen';
let selectedWasteType = null;
let scanningInProgress = false;

// Waste type database with dummy detection data
const wasteDatabase = {
    phone: {
        name: 'Smartphone',
        value: '₹450',
        confidence: '94%',
        explanation: 'High confidence based on shape, size, and material detection. Our AI identified the screen, ports, and battery components.',
        co2Saved: '1.8 kg',
        energyDays: '5',
        ecoPoints: 120
    },
    battery: {
        name: 'Lithium Battery',
        value: '₹180',
        confidence: '96%',
        explanation: 'Very high confidence. Battery terminals, cylindrical shape, and chemical composition clearly identified.',
        co2Saved: '0.9 kg',
        energyDays: '3',
        ecoPoints: 90
    },
    laptop: {
        name: 'Laptop Computer',
        value: '₹850',
        confidence: '92%',
        explanation: 'High confidence. Keyboard layout, screen hinge, and motherboard components detected successfully.',
        co2Saved: '3.2 kg',
        energyDays: '12',
        ecoPoints: 200
    },
    charger: {
        name: 'USB Charger',
        value: '₹120',
        confidence: '89%',
        explanation: 'Good confidence. USB port configuration and circuit board pattern recognized.',
        co2Saved: '0.5 kg',
        energyDays: '2',
        ecoPoints: 60
    }
};

// ==========================================
// Navigation System
// ==========================================

function navigateTo(screenId) {
    const currentScreenElement = document.querySelector('.screen.active');
    const targetScreenElement = document.getElementById(screenId + '-screen');
    
    if (!targetScreenElement) {
        console.error(`Screen ${screenId} not found`);
        return;
    }
    
    // Add exit animation to current screen
    if (currentScreenElement) {
        currentScreenElement.classList.add('exiting');
        
        // Wait for exit animation
        setTimeout(() => {
            currentScreenElement.classList.remove('active', 'exiting');
        }, 300);
    }
    
    // Activate new screen with entrance animation
    setTimeout(() => {
        targetScreenElement.classList.add('active');
        currentScreen = screenId + '-screen';
        
        // Screen-specific initialization
        initializeScreen(screenId);
    }, 150);
}

// ==========================================
// Screen Initialization
// ==========================================

function initializeScreen(screenId) {
    switch(screenId) {
        case 'home':
            resetAllStates();
            break;
        case 'scanning':
            resetScanningUI();
            break;
        case 'result':
            showDetectionResult();
            break;
    }
}

function resetAllStates() {
    selectedWasteType = null;
    scanningInProgress = false;
}

// ==========================================
// Waste Selection
// ==========================================

function selectWaste(wasteType) {
    selectedWasteType = wasteType;
    
    // Add visual feedback
    const selectedCard = event.currentTarget;
    selectedCard.style.transform = 'scale(0.95)';
    
    setTimeout(() => {
        selectedCard.style.transform = '';
        navigateTo('map');
    }, 200);
}

// ==========================================
// Scanning Functionality
// ==========================================

function resetScanningUI() {
    const scanContent = document.getElementById('scan-content');
    const scanText = document.querySelector('.scan-text');
    
    scanContent.innerHTML = `
        <svg viewBox="0 0 200 200" class="scan-icon">
            <circle cx="100" cy="100" r="60" fill="none" stroke="#A8E6CF" stroke-width="3" stroke-dasharray="5,5" class="rotate-animation"/>
            <path d="M 70 100 L 85 115 L 130 70" stroke="#5FB87C" stroke-width="6" fill="none" stroke-linecap="round" stroke-linejoin="round" opacity="0" class="check-animation"/>
        </svg>
        <p class="scan-text">Position your item in the frame</p>
    `;
}

function handleFileUpload(event) {
    const file = event.target.files[0];
    if (!file) return;
    
    // Simulate file processing
    startScanning();
}

function simulateScan() {
    startScanning();
}

function startScanning() {
    if (scanningInProgress) return;
    scanningInProgress = true;
    
    const scanContent = document.getElementById('scan-content');
    const scanText = scanContent.querySelector('.scan-text');
    
    // Update UI to show scanning
    scanText.textContent = 'Analyzing your item...';
    document.querySelector('.scan-frame').classList.add('scanning');
    
    // Simulate AI processing time
    setTimeout(() => {
        scanText.textContent = 'Item detected!';
        
        // Show checkmark animation
        const checkmark = scanContent.querySelector('.check-animation');
        if (checkmark) {
            checkmark.style.opacity = '1';
        }
        
        // Navigate to results after brief delay
        setTimeout(() => {
            navigateTo('result');
            scanningInProgress = false;
        }, 1000);
    }, 2500);
}

// ==========================================
// Result Screen - Step by Step Animation
// ==========================================

function showDetectionResult() {
    // Reset all steps
    document.querySelectorAll('.result-step').forEach(step => {
        step.classList.remove('active');
    });
    
    // Show detection result first
    document.getElementById('detection-result').classList.add('active');
    
    // Update detection data
    updateDetectionData();
}

function updateDetectionData() {
    if (!selectedWasteType) {
        selectedWasteType = 'phone'; // Default fallback
    }
    
    const wasteData = wasteDatabase[selectedWasteType];
    
    // Update item name
    const itemName = document.getElementById('detected-item-name');
    if (itemName) {
        itemName.textContent = wasteData.name;
    }
    
    // Update details
    const detailCards = document.querySelectorAll('.detail-card');
    if (detailCards.length >= 2) {
        detailCards[0].querySelector('.detail-value').textContent = wasteData.value;
        detailCards[1].querySelector('.detail-value').textContent = wasteData.confidence;
    }
    
    // Update explanation
    const explanation = document.querySelector('.confidence-explanation');
    if (explanation) {
        explanation.textContent = wasteData.explanation;
    }
}

function showNatureReaction() {
    // Hide detection result
    document.getElementById('detection-result').classList.remove('active');
    
    // Show nature reaction
    setTimeout(() => {
        document.getElementById('nature-reaction').classList.add('active');
        
        // Start with sad plant
        document.getElementById('sad-plant').classList.add('active');
        document.getElementById('sad-message').style.display = 'block';
        document.getElementById('happy-message').style.display = 'none';
        
        // After 2 seconds, transform to happy
        setTimeout(() => {
            transformToHappy();
        }, 2000);
    }, 300);
}

function transformToHappy() {
    const sadPlant = document.getElementById('sad-plant');
    const happyPlant = document.getElementById('happy-plant');
    const sadMessage = document.getElementById('sad-message');
    const happyMessage = document.getElementById('happy-message');
    const impactBtn = document.getElementById('impact-btn');
    
    // Fade out sad plant
    sadPlant.style.transition = 'opacity 0.5s ease-out';
    sadPlant.style.opacity = '0';
    
    setTimeout(() => {
        sadPlant.classList.remove('active');
        
        // Fade in happy plant
        happyPlant.classList.add('active');
        happyPlant.style.opacity = '0';
        happyPlant.style.transition = 'opacity 0.8s ease-in';
        
        setTimeout(() => {
            happyPlant.style.opacity = '1';
            
            // Trigger leaf and flower animations by adding class
            const leaves = happyPlant.querySelectorAll('.leaf-grow');
            const flowers = happyPlant.querySelectorAll('.flower-bloom');
            const sparkles = happyPlant.querySelectorAll('.sparkle');
            
            // Stagger the animations
            leaves.forEach((leaf, index) => {
                leaf.style.animationDelay = `${index * 0.1}s`;
            });
            
            flowers.forEach((flower, index) => {
                flower.style.animationDelay = `${0.4 + index * 0.05}s`;
            });
            
            sparkles.forEach((sparkle, index) => {
                sparkle.style.animation = 'sparkle-animation 1s ease-in-out infinite';
                sparkle.style.animationDelay = `${0.8 + index * 0.2}s`;
            });
        }, 50);
        
        // Switch messages
        setTimeout(() => {
            sadMessage.style.opacity = '0';
            sadMessage.style.transition = 'opacity 0.3s';
            
            setTimeout(() => {
                sadMessage.style.display = 'none';
                happyMessage.style.display = 'block';
                happyMessage.style.opacity = '0';
                happyMessage.style.transition = 'opacity 0.5s';
                
                setTimeout(() => {
                    happyMessage.style.opacity = '1';
                    
                    // Show impact button
                    setTimeout(() => {
                        impactBtn.style.display = 'flex';
                        impactBtn.style.opacity = '0';
                        impactBtn.style.transition = 'opacity 0.5s';
                        
                        setTimeout(() => {
                            impactBtn.style.opacity = '1';
                        }, 50);
                    }, 800);
                }, 50);
            }, 300);
        }, 500);
    }, 500);
}

function showImpact() {
    // Hide nature reaction
    document.getElementById('nature-reaction').classList.remove('active');
    
    // Show impact result
    setTimeout(() => {
        document.getElementById('impact-result').classList.add('active');
        
        // Update impact data
        updateImpactData();
        
        // Trigger pop-in animations for impact cards
        setTimeout(() => {
            const impactCards = document.querySelectorAll('.impact-card');
            impactCards.forEach((card, index) => {
                setTimeout(() => {
                    card.classList.add('pop-in');
                }, index * 150);
            });
        }, 200);
    }, 300);
}

function updateImpactData() {
    if (!selectedWasteType) {
        selectedWasteType = 'phone';
    }
    
    const wasteData = wasteDatabase[selectedWasteType];
    
    // Update impact values
    const impactCards = document.querySelectorAll('.impact-card');
    if (impactCards.length >= 3) {
        impactCards[0].querySelector('.impact-value').textContent = `+${wasteData.ecoPoints}`;
        impactCards[1].querySelector('.impact-value').textContent = wasteData.co2Saved;
        impactCards[2].querySelector('.impact-value').textContent = wasteData.energyDays;
    }
    
    // Update final message
    const finalMessage = document.querySelector('.final-message p');
    if (finalMessage) {
        finalMessage.textContent = `You saved enough energy to charge a phone for ${wasteData.energyDays} days! 🔋`;
    }
}

// ==========================================
// Interactive Elements Enhancement
// ==========================================

// Add ripple effect to buttons on click
function addRippleEffect(event) {
    const button = event.currentTarget;
    const ripple = document.createElement('span');
    const rect = button.getBoundingClientRect();
    const size = Math.max(rect.width, rect.height);
    const x = event.clientX - rect.left - size / 2;
    const y = event.clientY - rect.top - size / 2;
    
    ripple.style.width = ripple.style.height = size + 'px';
    ripple.style.left = x + 'px';
    ripple.style.top = y + 'px';
    ripple.classList.add('ripple');
    
    button.appendChild(ripple);
    
    setTimeout(() => {
        ripple.remove();
    }, 600);
}

// Add touch feedback for waste cards
document.addEventListener('DOMContentLoaded', () => {
    // Add ripple CSS dynamically
    const style = document.createElement('style');
    style.textContent = `
        button {
            position: relative;
            overflow: hidden;
        }
        
        .ripple {
            position: absolute;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.6);
            transform: scale(0);
            animation: ripple-animation 0.6s ease-out;
            pointer-events: none;
        }
        
        @keyframes ripple-animation {
            to {
                transform: scale(4);
                opacity: 0;
            }
        }
    `;
    document.head.appendChild(style);
    
    // Add event listeners to all buttons
    document.querySelectorAll('button').forEach(button => {
        button.addEventListener('click', addRippleEffect);
    });
    
    // Add hover effects to waste cards
    const wasteCards = document.querySelectorAll('.waste-card');
    wasteCards.forEach(card => {
        card.addEventListener('mouseenter', () => {
            card.style.transition = 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)';
        });
    });
});

// ==========================================
// Utility Functions
// ==========================================

// Smooth scroll to top when changing screens
function scrollToTop(smooth = true) {
    window.scrollTo({
        top: 0,
        behavior: smooth ? 'smooth' : 'auto'
    });
}

// Log analytics (placeholder for future implementation)
function logEvent(eventName, eventData) {
    console.log(`Analytics Event: ${eventName}`, eventData);
}

// ==========================================
// Accessibility Enhancements
// ==========================================

// Keyboard navigation support
document.addEventListener('keydown', (event) => {
    // ESC to go back
    if (event.key === 'Escape' && currentScreen !== 'home-screen') {
        const backButton = document.querySelector('.screen.active .btn-back');
        if (backButton) {
            backButton.click();
        }
    }
});

// Announce screen changes to screen readers
function announceScreenChange(screenName) {
    const announcement = document.createElement('div');
    announcement.setAttribute('role', 'status');
    announcement.setAttribute('aria-live', 'polite');
    announcement.style.position = 'absolute';
    announcement.style.left = '-10000px';
    announcement.textContent = `Navigated to ${screenName}`;
    document.body.appendChild(announcement);
    
    setTimeout(() => {
        announcement.remove();
    }, 1000);
}

// ==========================================
// Performance Optimizations
// ==========================================

// Preload images and assets
function preloadAssets() {
    // In a real app, preload images here
    console.log('Assets preloaded');
}

// Initialize app
window.addEventListener('load', () => {
    preloadAssets();
    console.log('EcoBin app initialized successfully! 🌱');
});

// ==========================================
// PWA Support (Optional Enhancement)
// ==========================================

// Register service worker for offline support
if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
        // Uncomment to enable PWA
        // navigator.serviceWorker.register('/sw.js')
        //     .then(reg => console.log('Service Worker registered'))
        //     .catch(err => console.log('Service Worker registration failed'));
    });
}

// Export functions for testing (if needed)
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        navigateTo,
        selectWaste,
        simulateScan,
        showNatureReaction,
        showImpact
    };
}
